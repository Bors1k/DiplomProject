import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-radbear',
  templateUrl: './radbear.component.html',
  styleUrls: ['./radbear.component.css']
})
export class RadbearComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
