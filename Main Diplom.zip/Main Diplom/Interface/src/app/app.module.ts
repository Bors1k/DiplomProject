import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BearingComponent } from './bearing/bearing.component';
import { from } from 'rxjs';
import { RadbearComponent } from './radbear/radbear.component';
import { BearComponent } from './bear/bear.component';
import { b8882Component } from './b8882/b8882.component';
import { b29241Component } from './b29241/b29241.component';
import { b8995Component } from './b8995/b8995.component';

const appRoutes: Routes = [
  {path: 'bearing', component: BearingComponent},
  {path: 'radbear', component: RadbearComponent},
  {path: 'bear', component: BearComponent},
  {path: 'b8882', component: b8882Component},
  {path: 'b8995', component: b8995Component},
  {path: 'b29241', component: b29241Component}
]
@NgModule({
  declarations: [
    AppComponent,
    BearingComponent,
    RadbearComponent,
    BearComponent,
    b8882Component,
    b29241Component,
    b8995Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
