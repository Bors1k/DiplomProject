module.exports = {
    HOST: "std-mysql.ist.mospolytech.ru",
    PORT: 3306,
    USER: "std_1570",
    PASSWORD: "Maria2021",
    DB: "std_1570"
  };